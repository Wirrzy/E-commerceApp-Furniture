//
//  SearchView.swift
//  FurHouse.Store
//
//  Created by Nar on 11/12/23.
//

import SwiftUI

struct SearchView: View {
    @State private var search: String = ""
    var body: some View {
        HStack{
            HStack{
                Image(systemName: "magnifyingglass")
                    .padding(.leading)
                
                TextField("Search furniture", text: $search)
                    .padding()
            }
            .background(Color("kSecondary"))
            .cornerRadius(15)
            
            Image(systemName: "camera")
                .padding()
                .foregroundColor(.white)
                .background(Color("kPrimary"))
                .cornerRadius(15)
        }
            .padding(.horizontal)
    }
}

#Preview {
    SearchView()
}
