//
//  CartView.swift
//  FurHouse.Store
//
//  Created by Nar on 12/12/23.
//

import SwiftUI

struct CartView: View {
    @EnvironmentObject var cartManager: CartManager
    var body: some View {
        ScrollView{
            if cartManager.products.count > 0{
                ForEach(cartManager.products, id: \.id){product in
                    CartProductView(product: product)
                }
                HStack{
                    Text("Your Total: ")
                    Spacer()
                    Text("Rp.\(cartManager.total).00")
                        .bold()
                    
                    
                }
                .padding()
                
                PaymentButton(action: {})
                    .padding()
            }else{
                
                Text("Cart Is Empty :(")
                    .bold()
                
            }
        }
        .navigationTitle(Text("Your Cart"))
        .padding(.top)
    }
}

#Preview {
    CartView()
        .environmentObject(CartManager())
}
