//
//  FurHouse_StoreApp.swift
//  FurHouse.Store
//
//  Created by Nar on 11/12/23.
//

import SwiftUI

@main
struct FurHouse_StoreApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
