//
//  Product.swift
//  FurHouse.Store
//
//  Created by Nar on 11/12/23.
//

import Foundation

struct Product : Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var description: String
    var supplier: String
    var price: Int
    var width: String
    var height: String
    var diameter: String
    
}

var productList = [
    Product(name: "Leather Couch",
            image: "FNC1",
            description: "Introducing our leather couch, a masterpiece of comfort and elegance that seamlessly combines style and functionality. Crafted with meticulous attention to detail, this exceptional piece of furniture is designed to enhance your living space with a touch of sophistication. Wrapped in genuine leather, the couch exudes a luxurious and inviting aura.",
            supplier: "ACE HARDWARE",
            price: 3500000,
            width: "300 cm",
            height: "150 cm",
            diameter: "110 cm"
           ),
    Product(name: "Cozy Couch",
            image: "FNC2",
            description: "Introducing our Cozy Comfort Couch, a haven of warmth and relaxation that beckons you to unwind and embrace tranquility. This sumptuous piece of furniture is designed with your utmost comfort in mind, creating an inviting retreat within the confines of your home. Enveloped in the softest, cloud-like fabric, the Cozy Comfort Couch promises a tactile experience like no other.",
            supplier: "RKM",
            price: 5000000,
            width: "350 cm",
            height: "170 cm",
            diameter: "115 cm"
           ),
    Product(name: "Room Couch",
            image: "FNC3",
            description: "Introducing our Comfort Craft Living Room Couch, a perfect blend of style and comfort designed to elevate your living space. This inviting piece of furniture seamlessly combines contemporary aesthetics with plush relaxation, creating a focal point that beckons you to unwind in style.",
            supplier: "IKEA",
            price: 2500000,
            width: "200 cm",
            height: "100 cm",
            diameter: "100 cm"
           ),
    Product(name: "Nice Leather Couch",
            image: "FNC4",
            description: "Introducing our Signature Leather Elegance Couch, a true embodiment of sophistication and comfort. Meticulously crafted to redefine luxury, this exquisite piece of furniture seamlessly blends timeless style with contemporary allure, making it the focal point of any distinguished living space.",
            supplier: "Walmart",
            price: 15000000,
            width: "450 cm",
            height: "250 cm",
            diameter: "200 cm"
           ),
    Product(name: "Leather King Bed",
            image: "FKB1",
            description: "Luxurious and sophisticated, our leather bed furniture exemplifies the epitome of comfort and style in bedroom decor. Crafted with precision and attention to detail, each piece showcases the rich texture and timeless allure of genuine leather. The bed frame, meticulously upholstered in high-quality leather, boasts a supple and smooth surface that invites touch.",
            supplier: "ACE HARDWARE",
            price: 10000000,
            width: "350 cm",
            height: "150 cm",
            diameter: "110 cm"
           ),
    Product(name: "Nice King Bed",
            image: "FKB2",
            description: "Introducing our Royal Serenity King Bed, an epitome of grandeur and comfort that transforms your bedroom into a sanctuary of luxury. Crafted with meticulous attention to detail, this regal piece of furniture seamlessly marries opulence with functionality, offering a majestic centerpiece for your sleeping haven. The bed frame, expertly crafted from the finest materials, boasts a stately presence.",
            supplier: "Walmart",
            price: 7500000,
            width: "250 cm",
            height: "125 cm",
            diameter: "100 cm"
           ),
    Product(name: "Comfy King Bed",
            image: "FKB3",
            description: "Introducing our Dream Cloud Comfort King Bed, a haven of indulgence and tranquility that redefines the art of sleeping in luxury. This sumptuous piece of furniture is designed with meticulous attention to detail, offering an oasis of comfort for those who appreciate the finer things in life.",
            supplier: "RKM",
            price: 12500000,
            width: "400 cm",
            height: "200 cm",
            diameter: "150 cm"
           ),
    Product(name: "Twin King bed",
            image: "FKB4",
            description: "Introducing our Harmony Haven Twin King Bed, a delightful fusion of style and functionality that caters to both individual comfort and shared spaces. Meticulously designed with versatility in mind, this elegant piece of furniture is perfect for creating a cozy retreat for one or accommodating the needs of two.",
            supplier: "IKEA",
            price: 20000000,
            width: "500 cm",
            height: "300 cm",
            diameter: "250 cm")
]
